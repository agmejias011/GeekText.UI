import React from "react";

import UserForm from "./userForm";

class signUppage extends React.Component {
	render() {
		return (
			<UserForm />
		);
	}
}

export default signUppage;