﻿namespace GeekText.UI.Controllers.MapperClasses
{
    public class SavedLaterJSON
    {
        public int book_id { get; set; }
        public int saved_qty { get; set; }
    }
}