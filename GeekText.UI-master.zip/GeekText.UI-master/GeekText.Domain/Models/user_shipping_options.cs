//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;
//using System.Text;

//namespace GeekText.Domain.Models
//{
//    [Table("user_shipping_options")]
//    public class user_shipping_options
//    {
//        public int user_id { get; set; }
//        [ForeignKey("user_id")]
//        //public Shipping_address shipping_address { get; set; }

//        public int address_id { get; set; }
//        [ForeignKey("address_id")]
//        //public Shipping_address shipping_address { get; set; }
//    }
//}