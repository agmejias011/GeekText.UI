﻿using GeekText.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeekText.UI.Controllers.MapperClasses
{
    public class ReturnSaveLaterforUI
    {
        public Book books { get; set; }
        public int qty { get; set; }

    }
}
