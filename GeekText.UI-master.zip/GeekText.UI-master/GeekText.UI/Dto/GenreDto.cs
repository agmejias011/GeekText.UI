﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GeekText.UI.Dto
{
    public class GenreDto
    {
        public int genre_id { get; set; }
        public string name { get; set; }
    }
}
