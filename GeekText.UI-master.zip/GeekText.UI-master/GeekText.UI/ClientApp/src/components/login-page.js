import React from "react";

import LoginForm from "./login-page/login-form";

class LoginPage extends React.Component {
	render() {
		return (
			<LoginForm/>
		);
	}
}

export default LoginPage;